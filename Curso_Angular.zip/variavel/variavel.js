let Nome = "Fabiano"
if(true){
    let Nome = "Silva"
    console.log(Nome)    
}
console.log(Nome)
