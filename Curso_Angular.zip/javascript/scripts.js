function validaNome(pNome, sNome){
    var primeiroNome = pNome;
    var segundoNome = sNome;

    if(pNome == "Fabiano" && sNome == "Silva"){
        alert("Acesso efetuado com sucesso !!!");
    }else{
        alert("Acesso negado!!");
    }
}
