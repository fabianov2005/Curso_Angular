class Veiculo{
    private modelo: string
    private velocidade: number = 0

    constructor(){
        
    }
}