import Carro from './Carro';

export default class Concessionaria{
    private endereco: string
    private listaDeCarros: Carro[]

    constructor (endere: string, lista: Carro[]){
        this.endereco = endere;
        this.listaDeCarros = lista;
    }

    public fornecerEndereco(): string {
            return this.endereco;
    }
    public mostrarListaCarros(): Carro[]{
        return this.listaDeCarros;
    }
}
