import Carro from './Carro';
import Pessoa, { carroInicial as MeuCarro } from './Pessoa';
import Concessionaria from './Concessionaria';


let carroA = new Carro("Dodge Journey",5);
let carroB = new Carro("Veloster",5);
let carroC = new Carro("Cerato",5);

let concesionaria = new Concessionaria("Minha Concessionaria", [carroA,carroB,carroC]);
 
//console.log(concesionaria.mostrarListaCarros())

let cliente = new Pessoa("Fabiano", "Veloster");

concesionaria.mostrarListaCarros().map((carro: Carro) => {
    console.log(carro)
    if(carro["modelo"] == cliente.dizerCarroPreferido()){
        
        //console.log(cliente.dizerCarroPreferido())
        cliente.comprarCarro(carro)
    }
})

console.log(cliente.dizerCarroQueTem())