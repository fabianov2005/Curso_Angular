import Carro from './Carro';


export default class Pessoa{
    nome: string;
    carroPreferido: Carro;
    carro: Carro;

    constructor(nomex: string, carroPreferido: string){
        this.carroPreferido = new Carro(carroPreferido,5);
        this.carro;
        this.nome = nomex;
    }

    public dizerNome() {
        return this.nome;
    }
    public dizerCarroPreferido() {
        return this.carroPreferido.getModelo();
    }
    public comprarCarro(carroComprado: Carro): void {
        this.carro = carroComprado;    
    }
    public dizerCarroQueTem(){
        return this.carro;
    }
}
export let carroInicial =   "PEUGEOT"