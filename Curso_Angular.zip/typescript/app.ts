let nome = umnome=>console.log("Meu Nome")

nome("Faiano")