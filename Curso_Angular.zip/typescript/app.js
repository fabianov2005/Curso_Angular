var nome = function (umnome: string) { return console.log("Meu Nome"); };
nome("Faiano");
